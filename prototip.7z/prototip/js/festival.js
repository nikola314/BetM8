function DodajUOmiljene(film){
    var index = 0;
    if(localStorage.getItem("OmiljeniIndex") != null){
        index = parseInt(localStorage.getItem("OmiljeniIndex"));
    }
    else{
        index = 0;
    }
    var i = 0;
    while(i<index){
        if(localStorage.getItem("Omiljeni"+index) == film){
            return;
        }
    }
    localStorage.setItem("Omiljeni"+index, film);
    index+= 1;
    localStorage.setItem("OmiljeniIndex", index);
}

function ispisiOmiljene(){
    var index = localStorage.getItem("OmiljeniIndex");
    if(index != null){
        var i = 0;
        index = parseInt(localStorage.getItem("OmiljeniIndex"));
        var s = "";
        while(i<index){
               s+= "<h2>"+localStorage.getItem("Omiljeni"+i) +"</h2>";
                i+=1;
              }
        document.getElementById("filmovi").innerHTML = s;
    }
    else{
        document.getElementById("filmovi").innerHTML = "<h2>Nema odabranih filmova</h2>";
    }
    localStorage.clear();
}